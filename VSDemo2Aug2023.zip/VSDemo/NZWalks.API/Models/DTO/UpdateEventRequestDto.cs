﻿using System.ComponentModel.DataAnnotations;
using VS.API.Models.Domain;

namespace VS.API.Models.DTO
{
    public class UpdateEventRequestDto
    {
        public string Title { get; set; }
        public string ImageUrl { get; set; }
        public string Description { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public string Venue { get; set; } 
    }
}
