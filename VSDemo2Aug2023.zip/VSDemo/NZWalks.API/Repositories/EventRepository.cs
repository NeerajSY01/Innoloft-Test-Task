﻿using Microsoft.EntityFrameworkCore;
using VS.API.Data;
using VS.API.Models.Domain;

namespace VS.API.Repositories
{
    public class EventRepository : IEventRepository
    {
        private readonly VSDbContext dbContext;

        public EventRepository(VSDbContext dbContext)
        {
            this.dbContext = dbContext;
        }

        public async Task<Event> CreateAsync(Event objEvent)
        {
            await dbContext.Events.AddAsync(objEvent);
            await dbContext.SaveChangesAsync();
            return objEvent;
        }

        public async Task<Event?> DeleteAsync(int id)
        {
            var existingEvent = await dbContext.Events.FirstOrDefaultAsync(x => x.EventID == id);

            if (existingEvent == null)
            {
                return null;
            }

            dbContext.Events.Remove(existingEvent);
            await dbContext.SaveChangesAsync();
            return existingEvent;
        }

        public async Task<List<Event>> GetAllAsync()
        {
            return await dbContext.Events.ToListAsync();
        }

        public async Task<Event?> GetByIdAsync(int id)
        {
            return await dbContext.Events.FirstOrDefaultAsync(x => x.EventID == id);
        }

        public async Task<Event?> UpdateAsync(int id, Event objEvent)
        {
            var existingEvent = await dbContext.Events.FirstOrDefaultAsync(x => x.EventID == id);

            if (existingEvent == null)
            {
                return null;
            }

            existingEvent.Title = objEvent.Title;
            existingEvent.StartDate = objEvent.StartDate;
            existingEvent.EndDate = objEvent.EndDate; 
            existingEvent.ImageUrl = objEvent.ImageUrl;
            //existingEvent.UpdatedBy = objEvent.UpdatedBy;
            //existingEvent.UpdatedOn = objEvent.UpdatedOn;

            await dbContext.SaveChangesAsync();
            return existingEvent;
        }
    }
}
