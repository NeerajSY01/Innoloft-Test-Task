﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using VS.API.Models.DTO;
using VS.API.Repositories;

namespace VS.API.Controllers
{
    public class UserController : Controller
    {
        private readonly IUserRepository eventRepository;
        private readonly IMapper mapper;

        public UserController(IUserRepository eventRepository,
            IMapper mapper)
        {
            this.eventRepository = eventRepository;
            this.mapper = mapper;
        }

        [HttpGet]
        [Route("{id:int}")]
        public async Task<IActionResult> GetById([FromRoute] int id)
        {
            var eventDomain = await eventRepository.GetByIdAsync(id);
            if (eventDomain == null)
            {
                return NotFound();
            }
            return Ok(mapper.Map<EventDto>(eventDomain));
        }
    }
}
