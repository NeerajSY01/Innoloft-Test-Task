﻿using Microsoft.EntityFrameworkCore;
using VS.API.Data;
using VS.API.Models.Domain;

namespace VS.API.Repositories
{
    public class UserRepository
    {
        private readonly VSDbContext dbContext;

        public UserRepository(VSDbContext dbContext)
        {
            this.dbContext = dbContext;
        }
        public async Task<User?> GetByIdAsync(int id)
        {
            return await dbContext.Users.FirstOrDefaultAsync(x => x.UserId == id);
        }
    }
}
