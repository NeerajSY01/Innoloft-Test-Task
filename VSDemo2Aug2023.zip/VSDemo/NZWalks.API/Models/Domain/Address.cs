﻿using Microsoft.Extensions.Hosting;
using System.ComponentModel.DataAnnotations;
using System.Net;

namespace VS.API.Models.Domain
{
    public class Address
    {
        [Key]
        public int AddressId { get; set; }
        public string Street { get; set; }
        public string Suite { get; set; }
        public string ZipCode { get; set; }
    }
}
