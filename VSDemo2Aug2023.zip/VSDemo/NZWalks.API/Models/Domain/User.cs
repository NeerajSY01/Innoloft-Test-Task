﻿using Microsoft.Extensions.Hosting;
using System.ComponentModel.DataAnnotations;
using System.Net;

namespace VS.API.Models.Domain
{
    public class User
    {
        [Key]
        public int UserId { get; set; }
        public string Name { get; set; }
        public string UserName { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public string WebSite { get; set; }

        public int CompanyId { get; set; }
        public int AddressId { get; set; }
        public Address Address { get; set; }
        public Company Company { get; set; }

    }
}
