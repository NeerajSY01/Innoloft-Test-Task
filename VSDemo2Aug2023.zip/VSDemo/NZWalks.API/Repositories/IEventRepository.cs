﻿using VS.API.Models.Domain;
using System.Runtime.InteropServices;

namespace VS.API.Repositories
{
    public interface IEventRepository
    {
        Task<List<Event>> GetAllAsync();

        Task<Event?> GetByIdAsync(int id);

        Task<Event> CreateAsync(Event ObjEvent);

        Task<Event?> UpdateAsync(int id, Event ObjEvent);

        Task<Event?> DeleteAsync(int id);
    }
}
