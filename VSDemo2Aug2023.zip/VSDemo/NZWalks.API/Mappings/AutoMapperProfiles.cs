﻿using AutoMapper;
using VS.API.Models.Domain;
using VS.API.Models.DTO;

namespace VS.API.Mappings
{
    public class AutoMapperProfiles : Profile
    {
        public AutoMapperProfiles()
        {
            CreateMap<Event, EventDto>().ReverseMap();
            CreateMap<AddEventRequestDto, Event>().ReverseMap();
            CreateMap<UpdateEventRequestDto, Event>().ReverseMap();             
        }
    }
}
