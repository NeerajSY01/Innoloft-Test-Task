﻿using VS.API.Models.Domain;

namespace VS.API.Models.DTO
{
    public class EventDto
    {
        public int EventID { get; set; }
        public string Title { get; set; }
        public string ImageUrl { get; set; }
        public string Description { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public string Venue { get; set; }
        public DateTime? CreatedOn { get; set; }
        public int CreatedBy { get; set; }
        public int? UpdatedOn { get; set; }
        public int? UpdatedBy { get; set; }
    }

}
