﻿using Microsoft.EntityFrameworkCore;
using System.Net;
using VS.API.Models.Domain;

namespace VS.API.Data
{
    public class VSDbContext: DbContext
    {
        public VSDbContext(DbContextOptions<VSDbContext> dbContextOptions): base(dbContextOptions)
        {

        }

        public DbSet<Event> Events { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<Address> Addresses { get; set; }
        public DbSet<Company> Companies { get; set; } 

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            
        }
    }
}
