﻿using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using VS.API.CustomActionFilters;
using VS.API.Data;
using VS.API.Models.Domain;
using VS.API.Models.DTO;
using VS.API.Repositories;

namespace VS.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EventsController : ControllerBase
    {
 
        private readonly IEventRepository eventRepository;
        private readonly IMapper mapper;

        private readonly IUserRepository userRepository;
        public EventsController(IEventRepository eventRepository,
            IMapper mapper, IUserRepository userRepository)
        { 
            this.eventRepository = eventRepository;
            this.mapper = mapper;
            this.userRepository = userRepository;
        }

        [HttpGet] 
        public async Task<IActionResult> GetAll()
        {
            var eventsDomain = await eventRepository.GetAllAsync();

            return Ok(mapper.Map<List<EventDto>>(eventsDomain));
        }

        [HttpGet]
        [Route("{id:int}")]
        public async Task<IActionResult> GetById([FromRoute] int id)
        {
            var eventDomain = await eventRepository.GetByIdAsync(id);
            if (eventDomain == null)
            {
                return NotFound();
            }
            return Ok(mapper.Map<EventDto>(eventDomain));
        }


        [HttpPost]
        [ValidateModel]
        public async Task<IActionResult> Create([FromBody] AddEventRequestDto addEventRequestDto)
        {
            var eventDomainModel = mapper.Map<Event>(addEventRequestDto);
            eventDomainModel = await eventRepository.CreateAsync(eventDomainModel);
            var eventDto = mapper.Map<EventDto>(eventDomainModel);

            return CreatedAtAction(nameof(GetById), new { id = eventDto.EventID }, eventDto);
        }

        [HttpPut]
        [Route("{id:int}")]
        [ValidateModel]
        public async Task<IActionResult> Update([FromRoute] int id, [FromBody] UpdateEventRequestDto updateEventRequestDto)
        {

            var eventDomainModel = mapper.Map<Event>(updateEventRequestDto);
            eventDomainModel = await eventRepository.UpdateAsync(id, eventDomainModel);

            if (eventDomainModel == null)
            {
                return NotFound();
            }

            return Ok(mapper.Map<EventDto>(eventDomainModel));
        }

        [HttpDelete]
        [Route("{id:int}")]
        public async Task<IActionResult> Delete([FromRoute] int id)
        {
            var eventDomainModel = await eventRepository.DeleteAsync(id);

            if (eventDomainModel == null)
            {
                return NotFound();
            }

            return Ok(mapper.Map<EventDto>(eventDomainModel));
        }
    }
}
