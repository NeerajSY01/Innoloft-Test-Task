﻿using Microsoft.Extensions.Hosting;
using System.ComponentModel.DataAnnotations;

namespace VS.API.Models.Domain
{
    public class Event
    {
        [Key]
        public int EventID { get; set; } 
        public string Title { get; set; }
        public string ImageUrl { get; set; }
        public string Description { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string Venue { get; set; }

        //public DateTime CreatedOn { get; set; }
        //public int CreatedBy { get; set; }
        //public int UpdatedOn { get; set; }
        //public int UpdatedBy { get; set;}      
    }
}
