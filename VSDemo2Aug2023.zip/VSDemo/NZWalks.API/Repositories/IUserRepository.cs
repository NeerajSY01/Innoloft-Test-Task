﻿using VS.API.Models.Domain;

namespace VS.API.Repositories
{
    public interface IUserRepository
    {
        Task<User?> GetByIdAsync(int id);
    }
}
